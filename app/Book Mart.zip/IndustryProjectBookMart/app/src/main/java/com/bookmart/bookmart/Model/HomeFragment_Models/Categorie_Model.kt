package com.bookmart.bookmart.Model.HomeFragment_Models

//we are creating a data class for categories Adapter in this data class we are storing IMAGE, TITLE,
data class Categorie_Model(var image:Int,var title:String)