package com.bookmart.bookmart.Activites

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bookmart.bookmart.R
import com.bookmart.bookmart.databinding.ActivitySetupUserProfileBinding
import com.bumptech.glide.Glide
import com.nguyenhoanglam.imagepicker.model.CustomColor
import com.nguyenhoanglam.imagepicker.model.CustomDrawable
import com.nguyenhoanglam.imagepicker.model.CustomMessage
import com.nguyenhoanglam.imagepicker.model.GridCount
import com.nguyenhoanglam.imagepicker.model.ImagePickerConfig
import com.nguyenhoanglam.imagepicker.model.IndicatorType
import com.nguyenhoanglam.imagepicker.model.RootDirectory
import com.nguyenhoanglam.imagepicker.ui.imagepicker.registerImagePicker


class SetupUserProfile : AppCompatActivity() {
    val binding by lazy {
        ActivitySetupUserProfileBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.username.requestFocus()
        val receivedData = intent.getStringExtra("userEmail")
        if (receivedData != null) {
            // Do something with the received data
            // For example, display it in a TextView
           binding.veriemail.setText(receivedData.toString().trim())


        }else{
            binding.veriemail.setText("harshvermadr30@gmail.com")
        }
        binding.veriemail.isEnabled=false
       val launcher = registerImagePicker { images ->
            // selected images
            if(images.isNotEmpty()){
                val image = images[0]
                Glide.with(this@SetupUserProfile)
                    .load(image.uri)
                    .into(binding.profileImage)
            }
        }
        val config = ImagePickerConfig(
            isFolderMode = true,
            isShowCamera = true,
            limitSize = 10,
            selectedIndicatorType = IndicatorType.NUMBER,
            rootDirectory = RootDirectory.DCIM,
            subDirectory = "Image Picker",
            folderGridCount = GridCount(2, 4),
            imageGridCount = GridCount(3, 5),
            customColor = CustomColor(
                background = "#000000",
                statusBar = "#000000",
                toolbar = "#212121",
                toolbarTitle = "#FFFFFF",
                toolbarIcon = "#FFFFFF",
                // ...
            ),
            customMessage = CustomMessage(
                reachLimitSize = "You can only select up to 10 images.",
                noImage = "No image found.",
                noPhotoAccessPermission = "Please allow permission to access photos and media.",
                noCameraPermission = "Please allow permission to access camera."
                // ...
            ),
            customDrawable = CustomDrawable(
                cameraIcon = R.drawable.google_icon,
                selectAllIcon = R.drawable.baseline_account_circle_24,
                unselectAllIcon = R.drawable.baseline_account_box_24,
                loadingImagePlaceholder = R.drawable.outline_error_24
                // ...
            ),
            // see more options below
        )
binding.imagepicker.setOnClickListener {
    launcher.launch(config)
}

    }

fun maicx() {

}
}