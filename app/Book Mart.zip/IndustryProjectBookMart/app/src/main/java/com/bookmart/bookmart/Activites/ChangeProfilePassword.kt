package com.bookmart.bookmart.Activites

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bookmart.bookmart.R

class ChangeProfilePassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_profile_password)
    }
}