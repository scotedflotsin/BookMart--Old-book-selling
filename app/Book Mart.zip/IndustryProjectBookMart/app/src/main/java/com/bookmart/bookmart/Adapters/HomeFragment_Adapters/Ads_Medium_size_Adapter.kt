package com.bookmart.bookmart.Adapters.HomeFragment_Adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bookmart.bookmart.Model.HomeFragment_Models.Ads_Medium_Model
import com.bookmart.bookmart.databinding.AdsMediumSizeRcyBinding

class Ads_Medium_size_Adapter(var datalist:ArrayList<Ads_Medium_Model>):RecyclerView.Adapter<Ads_Medium_size_Adapter.MyViewHolder>() {
    inner class MyViewHolder(var binding: AdsMediumSizeRcyBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
    var binding=AdsMediumSizeRcyBinding.inflate(LayoutInflater.from(parent.context),parent,false)

        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
return datalist.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

    }
}