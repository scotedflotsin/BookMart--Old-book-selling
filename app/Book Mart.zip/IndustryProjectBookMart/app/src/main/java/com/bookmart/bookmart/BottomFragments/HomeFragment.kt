
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.bookmart.bookmart.Adapters.HomeFragment_Adapters.AdSec_Adapter
import com.bookmart.bookmart.Adapters.HomeFragment_Adapters.Ads_Medium_size_Adapter
import com.bookmart.bookmart.Adapters.HomeFragment_Adapters.Categories_Adapters
import com.bookmart.bookmart.Adapters.HomeFragment_Adapters.TopAds_Adapter
import com.bookmart.bookmart.Model.HomeFragment_Models.AdsSec_Model
import com.bookmart.bookmart.Model.HomeFragment_Models.Ads_Medium_Model
import com.bookmart.bookmart.Model.HomeFragment_Models.Categorie_Model
import com.bookmart.bookmart.Model.HomeFragment_Models.TopAds_Model
import com.bookmart.bookmart.R
import com.bookmart.bookmart.databinding.FragmentHomeBinding
import kotlin.math.log


class HomeFragment:Fragment(R.layout.fragment_home) {
    // assign the _binding variable initially to null and
    // also when the view is destroyed again it has to be
    // set to null
  val binding by lazy{
      FragmentHomeBinding.inflate(layoutInflater)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {





        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // getting the recyclerview by its id

        // this creates a vertical layout Manager
        val layoutManager = LinearLayoutManager(activity,LinearLayoutManager.HORIZONTAL,false)
        val layoutManagerrr = LinearLayoutManager(activity,LinearLayoutManager.HORIZONTAL,false)
        val layoutManagerrrr = LinearLayoutManager(activity,LinearLayoutManager.HORIZONTAL,false)
        val layoutmanageradsMedium= GridLayoutManager(activity,2)
        binding.recyler.layoutManager = layoutManager
        binding.rec.layoutManager= layoutManagerrr
        binding.ryleoir.layoutManager= layoutManagerrrr
        binding.recylerviewmedium.layoutManager= layoutmanageradsMedium
        // ArrayList of class ItemsViewModel
        var data = ArrayList<Categorie_Model>()

        var data2 = ArrayList<TopAds_Model>()

        var data3 = ArrayList<AdsSec_Model>()

        var data4= ArrayList<Ads_Medium_Model>()
        // This loop will create 20 Views containing
        // the image with the count of view
        try {

            data.add(Categorie_Model(R.drawable.book, "mathmetic "))
            data.add(Categorie_Model(R.drawable.math_book, "computer"))
            data.add(Categorie_Model(R.drawable.book, "science "))
            data.add(Categorie_Model(R.drawable.book, "Ncert"))
            data.add(Categorie_Model(R.drawable.book, "bio"))
            data.add(Categorie_Model(R.drawable.book, "Mthec"))
        }catch (ece:Exception){

        }


        data2.add(TopAds_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data2.add(TopAds_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data2.add(TopAds_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data2.add(TopAds_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data2.add(TopAds_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))

        data3.add(AdsSec_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data3.add(AdsSec_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data3.add(AdsSec_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data3.add(AdsSec_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data3.add(AdsSec_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))


        data4.add(Ads_Medium_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data4.add(Ads_Medium_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data4.add(Ads_Medium_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data4.add(Ads_Medium_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data4.add(Ads_Medium_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))

        // This will pass the ArrayList to our Adapter
        var adapter = Categories_Adapters(data)
        var adapterrr= TopAds_Adapter(data2)
        var adapterrrr= AdSec_Adapter(data3)
        var adapterrrrrr= Ads_Medium_size_Adapter(data4)
        // Setting the Adapter with the recyclerview
        binding.recyler.adapter = adapter
        binding.rec.adapter = adapterrr
        binding.ryleoir.adapter = adapterrrr
        binding.recylerviewmedium.adapter= adapterrrrrr



        // on below line we are notifying adapter
        // that data has been updated.
        adapterrrrrr.notifyDataSetChanged()







    }

}