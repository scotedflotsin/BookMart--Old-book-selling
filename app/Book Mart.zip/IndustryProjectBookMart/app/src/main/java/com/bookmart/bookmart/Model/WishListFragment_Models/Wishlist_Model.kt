package com.bookmart.bookmart.Model.WishListFragment_Models

data class Wishlist_Model(var adImage:Int,var adTitle:String,var adPrise:String, var adYear:String,var adStandard:String)
