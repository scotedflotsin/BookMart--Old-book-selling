package com.bookmart.bookmart.Model.HomeFragment_Models

data class Ads_Medium_Model(var adImage:Int,var adTitle:String,var adPrise:String, var adYear:String,var adStandard:String)