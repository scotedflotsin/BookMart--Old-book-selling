package com.bookmart.bookmart.Activites

import AccountFragments
import Detailed_AdsViewFragment
import HistoryFragment
import HomeFragment
import WishListFragment
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


import com.bookmart.bookmart.R
import com.bookmart.bookmart.SearchAndFiltersBundle.RequiredFragments.SearchFragments
import com.bookmart.bookmart.Testingdemoclass.Navigaterclick
import com.bookmart.bookmart.databinding.ActivityMainHomeBinding
import com.google.android.material.navigation.NavigationView
import com.google.android.material.navigation.NavigationView.OnNavigationItemSelectedListener
import render.animations.Render

class MainHome : AppCompatActivity() {
   val binding by lazy {
       ActivityMainHomeBinding.inflate(layoutInflater)
   }

  //  private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val firstFragment=HomeFragment()
        val secondFragment=WishListFragment()
        val thirdFragment=HistoryFragment()
        val fourthFragment=AccountFragments()
        val fifthFragment=SearchFragments()
        val ads_viewFragments=Detailed_AdsViewFragment()

        setCurrentFragment(firstFragment)

            binding.bottomNavigationView.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.homemenu->
                    setCurrentFragment(ads_viewFragments)

                R.id.wishlistmenu->setCurrentFragment(secondFragment)
                R.id.historymenu->setCurrentFragment(thirdFragment)
                R.id.accountmenu->setCurrentFragment(fourthFragment)

            }
            true
        }








    }

    private fun setCurrentFragment(fragment: Fragment)=
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.frame_layout,fragment)
            commit()
    }


//    private fun setupDrawer() {
//        val navDrawer = findViewById<LinearLayout>(R.id.nav_drawer)
//        navDrawer.setOnClickListener {
//            // Handle navigation item clicks
//            // You can launch different fragments or activities based on the clicked item
//        }
//    }



}