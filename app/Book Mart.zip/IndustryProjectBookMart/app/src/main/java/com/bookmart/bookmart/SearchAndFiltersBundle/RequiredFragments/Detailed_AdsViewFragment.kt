import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bookmart.bookmart.Adapters.Ads_viewAdapter_suggestion.Ads_view_suggestion_Adspter
import com.bookmart.bookmart.Model.AdsViewModels.AdsView_ads_Model
import com.bookmart.bookmart.Model.HomeFragment_Models.Categorie_Model
import com.bookmart.bookmart.Model.HomeFragment_Models.TopAds_Model
import com.bookmart.bookmart.R
import com.bookmart.bookmart.databinding.FragmentDetailedAdsViewBinding
import com.denzcoskun.imageslider.models.SlideModel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class Detailed_AdsViewFragment:Fragment(R.layout.fragment_detailed__ads_view), OnMapReadyCallback {
    val binding by lazy {
        FragmentDetailedAdsViewBinding.inflate(layoutInflater)
    }
    private lateinit var googleMap: GoogleMap
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val imageList = ArrayList<SlideModel>() // Create image list
// imageList.add(SlideModel("String Url" or R.drawable)
// imageList.add(SlideModel("String Url" or R.drawable, "title") You can add title
        imageList.add(SlideModel("https://bit.ly/2YoJ77H", "The animal population decreased by 58 percent in 42 years."))
        imageList.add(SlideModel("https://bit.ly/2BteuF2", "Elephants and tigers may become extinct."))
        imageList.add(SlideModel("https://bit.ly/3fLJf72", "And people do that."))
        binding.imageSlider.setImageList(imageList)

       binding.mapView.onCreate(savedInstanceState)
        binding.mapView.getMapAsync(this)
        val layoutManager = LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL,false)
        binding.rec.layoutManager = layoutManager
        var data = ArrayList<AdsView_ads_Model>()

        data.add(AdsView_ads_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data.add(AdsView_ads_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data.add(AdsView_ads_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data.add(AdsView_ads_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))
        data.add(AdsView_ads_Model(R.drawable.bookdemo,"Rs math", "$345","2023","10th"))


val adapter=Ads_view_suggestion_Adspter(data)
        binding.rec.adapter=adapter



        return binding.root
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Add a marker to a specific location
        val location = LatLng(37.7749, -122.4194) // San Francisco coordinates
        googleMap.addMarker(MarkerOptions().position(location).title("Marker in San Francisco"))
        googleMap.moveCamera(com.google.android.gms.maps.CameraUpdateFactory.newLatLng(location))
    }

    override fun onResume() {
        super.onResume()
        binding.mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        binding.mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        binding.mapView.onLowMemory()
    }
}