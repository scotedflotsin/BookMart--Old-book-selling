package com.bookmart.bookmart.Activites

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bookmart.bookmart.R

class LoginScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_screen)
    }
}