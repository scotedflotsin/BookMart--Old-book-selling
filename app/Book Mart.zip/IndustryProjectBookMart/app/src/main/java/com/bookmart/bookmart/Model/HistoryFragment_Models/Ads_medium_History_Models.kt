package com.bookmart.bookmart.Model.HistoryFragment_Models

data class Ads_medium_History_Models(var adImage:Int,var adTitle:String,var adPrise:String, var adYear:String,var adStandard:String)
