package com.bookmart.bookmart.Model.AdsViewModels

data class AdsView_ads_Model(var adImage:Int,var adTitle:String,var adPrise:String, var adYear:String,var adStandard:String)