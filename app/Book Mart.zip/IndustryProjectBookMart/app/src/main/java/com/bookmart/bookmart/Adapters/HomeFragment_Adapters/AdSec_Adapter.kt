package com.bookmart.bookmart.Adapters.HomeFragment_Adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bookmart.bookmart.Model.HomeFragment_Models.AdsSec_Model
import com.bookmart.bookmart.databinding.AdsLightSizeRcyBinding

class AdSec_Adapter(var dataList:ArrayList<AdsSec_Model>):RecyclerView.Adapter<AdSec_Adapter.MyViewHolder>(){
    inner class MyViewHolder(var binding:AdsLightSizeRcyBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding=AdsLightSizeRcyBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
  return dataList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

    }
}