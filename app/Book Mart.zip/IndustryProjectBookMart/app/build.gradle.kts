plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.android.libraries.mapsplatform.secrets-gradle-plugin")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.bookmart.bookmart"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.bookmart.bookmart"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.10.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.gridlayout:gridlayout:1.0.0")
    implementation("com.google.firebase:firebase-analytics-ktx:21.3.0")
    implementation("com.google.firebase:firebase-auth-ktx:22.1.2")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    //SDP - a scalable size unit
    implementation("com.intuit.sdp:sdp-android:1.1.0")
    //material design
    implementation("com.google.android.material:material:1.11.0-alpha03")
    //For round profileimageview in account fragments
    implementation("de.hdodenhof:circleimageview:3.1.0")
    //For GIF as a animation
    implementation("pl.droidsonroids.gif:android-gif-drawable:1.2.22")
    // dependency for slider view
    implementation("com.github.denzcoskun:ImageSlideshow:0.1.2")
    //For google maps implementation
    implementation("com.google.android.gms:play-services-maps:18.1.0")
    implementation("com.google.android.gms:play-services-location:21.0.1")
    //drawer navigation
    implementation ("androidx.navigation:navigation-fragment-ktx:2.7.4")
    implementation ("androidx.navigation:navigation-ui-ktx:2.7.4")
    //For animations > https://github.com/gayanvoice/android-animations-kotlin
    implementation ("com.github.gayanvoice:android-animations-kotlin:1.0.1")
    // Import the BoM for the Firebase platform
    implementation("com.google.firebase:firebase-bom:32.3.1")
    implementation ("com.google.firebase:firebase-auth:22.1.2")
    implementation ("com.google.android.gms:play-services-auth:20.7.0")

//facebook librery
    implementation ("com.facebook.android:facebook-android-sdk:16.2.0")

    // Facebook Login only
    implementation ("com.facebook.android:facebook-login:16.2.0")
//Volly for android networking
    implementation("com.android.volley:volley:1.2.1")
    //spinner view for loading
    implementation ("com.github.razir.progressbutton:progressbutton:2.1.0")
//image picker

        implementation ("com.github.nguyenhoanglam:ImagePicker:1.6.1")

//Glide
    implementation ("com.github.bumptech.glide:glide:4.16.0")

}